from django.urls import path
from .import views
urlpatterns = [
    path('', views.index,name="My First Shop"),
    path('about/', views.about,name="Aboutus"),
    path('contact/', views.contact,name="Contactus"),
    path('tracker/', views.tracker,name="TrackingStatus"),
    path('search/', views.search,name="Search"),
    path('productview/', views.productView,name="productView"),
    path('checkout/', views.checkout,name="Checkout"),
]
