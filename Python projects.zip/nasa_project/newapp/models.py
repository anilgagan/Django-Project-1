from __future__ import unicode_literals
from django.db import models
from django.contrib.auth.models import User
# Create your models here.


class TreasureGram(models.Model):
    user = models.ForeignKey(User,on_delete=True,null=True)
    name = models.CharField(max_length=50,null=True)
    value = models.CharField(max_length=100,null=True)
    material = models.CharField(max_length=50,null=True)
    location = models.CharField(max_length=100,null=True)
    image_url =models.CharField(max_length=1000,null=True)

    def __str__(self):
        return self.name



class Document(models.Model):
    description = models.CharField(max_length=255, blank=True)
    document = models.FileField(upload_to='documents/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
