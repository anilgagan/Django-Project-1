from django.urls import path,reverse_lazy
from django.contrib.auth.views import login,logout, logout_then_login
from django.contrib.auth.views import PasswordChangeView,PasswordChangeDoneView
from django.conf import settings
from django.conf.urls.static import static
from . import views

#app_name='Treasurename'
urlpatterns = [
    path('', views.Home,name='home'),
    path('login/',login,name='login'),
    path('logout/',logout,name='logout'),
    path('detail/<int:val>/',views.detail,name='detail'),
    path('add/',views.addnew,name='new_treasure'),
    path('edit/<int:val>',views.treasure_edit,name='edit_treasure'),
    path('password-change/',PasswordChangeView.as_view(success_url=reverse_lazy('password_change_done')),name="password_change"),
    path('password-change/done/',PasswordChangeDoneView.as_view(),name="password_change_done"),
    path(r'^remove_items/(?P<pk>[0-9]+)$', views.remove_items, name='itemdalete'),
    path('signup/', views.signup, name='signup'),
    path('add/simpleupload/', views.simple_upload, name='simple_upload'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
