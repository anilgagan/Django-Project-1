from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from newapp.models import TreasureGram

class TreasuresForm(forms.ModelForm):
    name = forms.CharField(max_length=200)
    value = forms.CharField(max_length=50)
    location = forms.CharField(max_length=300)
    material = forms.CharField(max_length=30)
    image_url = forms.CharField(max_length=1000)
    class Meta:
        model = TreasureGram
        fields = ['name', 'value', 'location', 'material', 'image_url']

class SignUpForm(UserCreationForm):
    first_name = forms.CharField(max_length=30, required=False, help_text='Optional.')
    last_name = forms.CharField(max_length=30, required=False, help_text='Optional.')
    email = forms.EmailField(max_length=254, help_text='Required. Inform a valid email address.')

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1', 'password2', )
