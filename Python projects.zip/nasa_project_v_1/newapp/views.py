from django.shortcuts import render,redirect,get_object_or_404
from django.http import HttpResponse
from .models import TreasureGram
from .forms import TreasuresForm
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy

def Home(request):
    all_treasures = TreasureGram.objects.all()
    return render(request,'Treasures/home.html',{'all_treasures':all_treasures})

def detail(request,val):
    treasure= TreasureGram.objects.get(id=val)
    return render(request,'Treasures/detail.html',{'treasureval':treasure})
    #return  HttpResponse('<h1>Detail page for :-'+str(val)+'</h1>')

# def addnew(request):
#     print(request.POST)
#     if request.POST :
#         name1 = request.POST.get('name', '')
#         value1 = request.POST.get('value', '')
#         material1 = request.POST.get('material', '')
#         location1 = request.POST.get('location', '')
#         image_url1 = request.POST.get('image_url', '')
#         formdata = TreasureGram(name=name1,value=value1,material=material1,location=location1,image_url=image_url1)
#         formdata.save()
#         return  redirect('/')
#     else:
#         form = TreasuresForm()
#         return render(request,'Treasures/new_form.html',{'form':form})


def addnew(request,pk=None):
    if pk:
        fulladdress = get_object_or_404(TreasureGram, id=pk)
    else:
        #fulladdress = Fulladdress(name=request.name)
        fulladdress=None
    form = TreasuresForm(request.POST or None,instance=fulladdress)
    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return  redirect('/')
    else:
        form = TreasuresForm(instance=fulladdress)
    return render(request,'Treasures/new_form.html',{'form':form})


def treasure_edit(request,val):
    treasure1 = get_object_or_404(TreasureGram, pk=val)
    if request.method =='POST':
        form = TreasuresForm(request.POST,instance=treasure1)
        form.save()
        return  redirect('/')
    else:
        form = TreasuresForm(instance=treasure1)
        return render(request,'Treasures/new_form.html',{'form':form})


def LoginForm(request):
    if request.method == 'POST':
        form1 = UserCreationForm(request.POST)
        if form1.is_valid():
            form1.save()
            username= form1.cleaned_data.get('username')
            rpassword= form1.cleaned_data.get('password')
            user = authenticate(request,username=username,password=rpassword)
            login(request,user)
            #context = {'form':form1}
            #return render(request, "Treasures/home.html",{'form':form1})
            return HttpResponseRedirect(reverse_lazy('/'))
    else:
        form1 =UserCreationForm()
        return render(request,'Treasures/login.html',{'form':form1})
        #context = {'form':form1}
        #return render(request, "Treasures/login.html", context)


def logoutForm(request):
    logout(request)
    return redirect('/')

def remove_items(request,pk):
    item = TreasureGram.objects.get(id=pk)
    item.delete()
    return  redirect('/')
