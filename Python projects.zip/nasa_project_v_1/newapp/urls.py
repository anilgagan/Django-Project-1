from django.urls import path
from . import views

#app_name='Treasurename'
urlpatterns = [
    path('', views.Home,name='home'),
    path('detail/<int:val>/',views.detail,name='detail'),
    path('add/',views.addnew,name='new_treasure'),
    path('edit/<int:val>',views.treasure_edit,name='edit_treasure'),
    path('login/',views.LoginForm,name='login'),
    path('logout/',views.logoutForm,name='logout'),
    path(r'^remove_items/(?P<pk>[0-9]+)$', views.remove_items, name='itemdalete'),
]
