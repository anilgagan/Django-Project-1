from django import forms
from newapp.models import TreasureGram

class TreasuresForm(forms.ModelForm):
    name = forms.CharField(max_length=200)
    value = forms.CharField(max_length=50)
    location = forms.CharField(max_length=300)
    material = forms.CharField(max_length=30)
    image_url = forms.CharField(max_length=1000)
    class Meta:
        model = TreasureGram
        fields = ['name', 'value', 'location', 'material', 'image_url']
